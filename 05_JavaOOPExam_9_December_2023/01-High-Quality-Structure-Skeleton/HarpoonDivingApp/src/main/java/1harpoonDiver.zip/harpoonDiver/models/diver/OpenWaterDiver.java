package harpoonDiver.models.diver;

public class OpenWaterDiver extends BaseDiver{
    public OpenWaterDiver(String name) {
        super(name, 30);
    }

    @Override
    public void shoot() {

    }
}
