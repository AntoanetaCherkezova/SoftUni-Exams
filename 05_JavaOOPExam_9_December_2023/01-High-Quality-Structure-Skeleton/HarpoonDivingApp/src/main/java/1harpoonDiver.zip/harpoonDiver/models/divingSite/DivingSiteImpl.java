package harpoonDiver.models.divingSite;

import harpoonDiver.models.diving.Diving;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class DivingSiteImpl implements DivingSite {
    private String name;
    private List<String> seaCreatures;

    public DivingSiteImpl(String name) {
        this.name = name;
        this.seaCreatures = new ArrayList<>();
    }

    @Override
    public Collection<String> getSeaCreatures() {
        return null;
    }

    @Override
    public String getName() {
        return null;
    }
}
