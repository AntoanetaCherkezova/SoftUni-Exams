package harpoonDiver.models.diver;

public class DeepWaterDiver extends BaseDiver{
    public DeepWaterDiver(String name) {
        super(name, 90);
    }

}
