document.addEventListener('DOMContentLoaded', () => {
    const foodInput = document.getElementById('food');
    const timeInput = document.getElementById('time');
    const caloriesInput = document.getElementById('calories');
    const addMealBtn = document.getElementById('add-meal');
    const editMealBtn = document.getElementById('edit-meal');
    const loadMealsBtn = document.getElementById('load-meals');
    const listDiv = document.getElementById('list');
    let currentMealId = null;

    loadMealsBtn.addEventListener('click', loadMeals);
    addMealBtn.addEventListener('click', addMeal);
    editMealBtn.addEventListener('click', editMeal);

    function loadMeals() {
        fetch('http://localhost:3030/jsonstore/tasks')
            .then(res => res.json())
            .then(data => {
                listDiv.innerHTML = '';
                for (const id in data) {
                    const m = data[id];
                    const mealDiv = document.createElement('div');
                    mealDiv.className = 'meal';
                    mealDiv.innerHTML = `
                        <h2>${m.food}</h2>
                        <h3>${m.time}</h3>
                        <h3>${m.calories}</h3>
                        <div id="meal-buttons">
                            <button class="change-meal" onclick="changeMeal('${id}')">Change</button>
                            <button class="delete-meal" onclick="deleteMeal('${id}')">Delete</button>
                        </div>
                    `;
                    listDiv.appendChild(mealDiv);
                }
            });
    }
    

    function addMeal() {
        const meal = {
            food: foodInput.value,
            time: timeInput.value,
            calories: caloriesInput.value
        };

        fetch('http://localhost:3030/jsonstore/tasks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(meal)
        }).then(() => {
            clearInputs();
            loadMeals();
        });
    }

    function changeMeal(id) {
        fetch(`http://localhost:3030/jsonstore/tasks/${id}`)
            .then(res => res.json())
            .then(data => {
                foodInput.value = data.food;
                timeInput.value = data.time;
                caloriesInput.value = data.calories;
                currentMealId = id;
                addMealBtn.disabled = true;
                editMealBtn.disabled = false;
            });
    }

    function editMeal() {
        const meal = {
            food: foodInput.value,
            time: timeInput.value,
            calories: caloriesInput.value
        };

        fetch(`http://localhost:3030/jsonstore/tasks/${currentMealId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(meal)
        }).then(() => {
            clearInputs();
            loadMeals();
            addMealBtn.disabled = false;
            editMealBtn.disabled = true;
            currentMealId = null;
        });
    }

    function deleteMeal(id) {
        fetch(`http://localhost:3030/jsonstore/tasks/${id}`, {
            method: 'DELETE'
        }).then(() => {
            loadMeals();
        });
    }

    function clearInputs() {
        foodInput.value = '';
        timeInput.value = '';
        caloriesInput.value = '';
    }
    // ... [rest of the functions remain the same] ...

    window.changeMeal = changeMeal;
    window.deleteMeal = deleteMeal;
});